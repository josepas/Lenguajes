class BT
    attr_accessor :n
    attr_reader :l, :r

    def initialize(n, l=nil, r=nil)
    end

    def each
    end
end

class RT
    attr_accessor :n
    attr_reader :ss

    def initialize(n, *sons)
    end

    def each
    end
end