module Foldable

    def fold(b, &bloque)
    end

    def map &block
    end

    def map! &block
    end
end