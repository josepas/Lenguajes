module DFS
    def dfs &block
    end

    def dfs! &block
    end
end